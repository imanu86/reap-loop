Set-StrictMode -Version 2.0

function Get-A3TextSha256 {
    param([Parameter(Mandatory = $true)][AllowEmptyString()][string]$Text)
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $bytes = [System.Text.UTF8Encoding]::new($false).GetBytes($Text)
        return ([BitConverter]::ToString($sha.ComputeHash($bytes)) -replace '-', '').ToLowerInvariant()
    } finally {
        $sha.Dispose()
    }
}

function Get-A3FileSha256 {
    param([Parameter(Mandatory = $true)][string]$Path)
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}

function Write-A3Json {
    param(
        [Parameter(Mandatory = $true)]$Value,
        [Parameter(Mandatory = $true)][string]$Path,
        [int]$Depth = 16
    )
    $json = $Value | ConvertTo-Json -Depth $Depth
    [System.IO.File]::WriteAllText(
        $Path, $json + [Environment]::NewLine,
        [System.Text.UTF8Encoding]::new($false))
}

function Get-A3Geometry {
    param([Parameter(Mandatory = $true)][ValidateSet(250, 256, 600, 768, 2048)][int]$PrefillChunk)
    $rawRows = [Math]::Min(
        8192,
        [int]([Math]::Ceiling((128.0 + $PrefillChunk) / 256.0) * 256))
    $batchBytesPerToken = [UInt64]1018356
    $scoresMaskBytesPerToken = [UInt64]300016
    $selectedBytesPerToken = [UInt64]2048
    $rawBytes = [UInt64](43L * $rawRows * 512L * 4L)
    $mtpRawBytes = [UInt64]($rawRows * 512L * 4L)
    $compressedBytes = [UInt64]2064153600
    $batchBytes = [UInt64]($batchBytesPerToken * $PrefillChunk)
    $scoresMaskBytes = [UInt64]($scoresMaskBytesPerToken * $PrefillChunk)
    $selectedBytes = [UInt64]($selectedBytesPerToken * $PrefillChunk)
    $contextEstimateBytes = $rawBytes + $compressedBytes + $scoresMaskBytes
    $knownChunkSensitiveBytes =
        $rawBytes + $mtpRawBytes + $batchBytes + $scoresMaskBytes + $selectedBytes
    return [ordered]@{
        ctx_capacity = 150000
        prefill_chunk = $PrefillChunk
        expected_raw_rows = $rawRows
        comp_cap = 37502
        compressed_bytes_common = $compressedBytes
        raw_kv_43_layer_bytes = $rawBytes
        mtp_raw_bytes_if_active = $mtpRawBytes
        eager_batch_bytes = $batchBytes
        scores_mask_bytes = $scoresMaskBytes
        selected_bytes = $selectedBytes
        context_estimate_bytes = $contextEstimateBytes
        context_estimate_mib = [Math]::Round($contextEstimateBytes / 1MB, 6)
        known_chunk_sensitive_bytes = $knownChunkSensitiveBytes
        known_chunk_sensitive_mib = [Math]::Round($knownChunkSensitiveBytes / 1MB, 6)
        conditional_batch_ffn_out_bytes = [UInt64](16384L * $PrefillChunk)
    }
}

function New-A3EffectiveManifest {
    param(
        [Parameter(Mandatory = $true)][string]$TemplatePath,
        [Parameter(Mandatory = $true)][ValidateSet(250, 600, 768)][int]$PrefillChunk,
        [Parameter(Mandatory = $true)][ValidateSet('Pending', '0', '1')][string]$G73Open
    )
    $g73Value = if ($G73Open -eq 'Pending') { 'PENDING_A2' } else { $G73Open }
    $raw = [System.IO.File]::ReadAllText($TemplatePath, [System.Text.Encoding]::UTF8)
    $rendered = $raw.Replace('{{PREFILL_CHUNK}}', [string]$PrefillChunk).
        Replace('{{G73_OPEN}}', $g73Value)
    if ($rendered -match '\{\{') {
        throw 'unresolved manifest template placeholder'
    }
    $lines = @(
        $rendered -split '\r?\n' |
            Where-Object { -not [string]::IsNullOrWhiteSpace($_) }
    )
    if ($lines.Count -ne 47) {
        throw "effective manifest must contain exactly 47 variables; got $($lines.Count)"
    }
    $values = [ordered]@{}
    foreach ($line in $lines) {
        if ($line -notmatch '^([A-Z0-9_]+)=(.*)$') {
            throw "invalid manifest line: $line"
        }
        if ($values.Contains($matches[1])) {
            throw "duplicate manifest variable: $($matches[1])"
        }
        $values[$matches[1]] = $matches[2]
    }
    if ([string]$values.DS4_METAL_PREFILL_CHUNK -ne [string]$PrefillChunk) {
        throw 'rendered prefill chunk mismatch'
    }
    if ($values.Contains('DS4_METAL_GRAPH_RAW_CAP')) {
        throw 'RAW_CAP must not be present in the 47-variable treatment manifest'
    }
    $canonical = ($lines -join "`n") + "`n"
    $nonTreatment = $canonical -replace
        'DS4_METAL_PREFILL_CHUNK=(250|600|768)',
        'DS4_METAL_PREFILL_CHUNK=<TREATMENT>'
    return [pscustomobject]@{
        Lines = $lines
        Values = $values
        CanonicalText = $canonical
        Sha256 = Get-A3TextSha256 -Text $canonical
        NonTreatmentSha256 = Get-A3TextSha256 -Text $nonTreatment
        RunEligible = $G73Open -ne 'Pending'
    }
}

function Get-A3LongPrefillPrompt {
    $rows = for ($i = 0; $i -lt 96; $i++) {
        "Blocco A3 deterministico $i. Analizza una piattaforma software distribuita: " +
        "descrivi requisito, rischio, controllo, metrica, rollback e prova osservabile. " +
        "Mantieni ogni affermazione collegata a un'evidenza e non omettere i casi limite."
    }
    return ($rows -join "`n")
}

function Get-A3RequestMetrics {
    param(
        [Parameter(Mandatory = $true)][AllowEmptyString()][string]$LogText,
        [Parameter(Mandatory = $true)][string]$ResponsePath,
        [Parameter(Mandatory = $true)][double]$ClientWallSeconds,
        [Parameter(Mandatory = $true)][string]$Name
    )
    $ctxMatches = [regex]::Matches(
        $LogText, 'chat ctx=(\d+)\.\.(\d+):(\d+) prompt start')
    $prompt = -1
    $cached = -1
    $computed = -1
    if ($ctxMatches.Count -gt 0) {
        $m = $ctxMatches[$ctxMatches.Count - 1]
        $cached = [int]$m.Groups[1].Value
        $prompt = [int]$m.Groups[2].Value
        $computed = [int]$m.Groups[3].Value
    }
    $prefillSeconds = $null
    $prefillMatches = [regex]::Matches(
        $LogText, 'chat ctx=\d+\.\.\d+:\d+[^\r\n]* prompt done ([0-9.]+)s')
    if ($prefillMatches.Count -gt 0) {
        $prefillSeconds = [double]$prefillMatches[$prefillMatches.Count - 1].Groups[1].Value
    }
    $ttftSeconds = $null
    $decodeSeconds = $null
    foreach ($m in [regex]::Matches(
        $LogText,
        '\[request-phase\] event=([a-z-]+) mono=([0-9.]+) since_prompt=([-0-9.]+) since_decode=([-0-9.]+)')) {
        if ($m.Groups[1].Value -eq 'first-token-ready') {
            $ttftSeconds = [double]$m.Groups[3].Value
        }
        if ($m.Groups[1].Value -eq 'request-end') {
            $decodeSeconds = [double]$m.Groups[4].Value
        }
    }
    $graphMs = @(
        [regex]::Matches(
            $LogText,
            'metal graph token pos=(\d+) encode=([0-9.]+) ms execute=([0-9.]+) ms read=([0-9.]+) ms total=([0-9.]+) ms') |
            ForEach-Object { [double]$_.Groups[5].Value }
    )
    $response = $null
    $content = ''
    $completion = 0
    $finishReason = ''
    if (Test-Path -LiteralPath $ResponsePath) {
        $response = [System.IO.File]::ReadAllText(
            $ResponsePath, [System.Text.Encoding]::UTF8) | ConvertFrom-Json
        $content = [string]$response.choices[0].message.content
        $completion = [int]$response.usage.completion_tokens
        $finishReason = [string]$response.choices[0].finish_reason
        if ($prompt -lt 0) {
            $prompt = [int]$response.usage.prompt_tokens
        }
    }
    $graphTps = $null
    if ($graphMs.Count -gt 0) {
        $graphTps = [Math]::Round(
            $graphMs.Count / ((($graphMs | Measure-Object -Sum).Sum) / 1000.0), 6)
    }
    $prefillTps = $null
    if ($null -ne $prefillSeconds -and $prefillSeconds -gt 0 -and $computed -ge 0) {
        $prefillTps = [Math]::Round($computed / $prefillSeconds, 6)
    }
    $decodeTps = $null
    if ($null -ne $decodeSeconds -and $decodeSeconds -gt 0) {
        $decodeTps = [Math]::Round($completion / $decodeSeconds, 6)
    }
    $wallTps = if ($ClientWallSeconds -gt 0) {
        [Math]::Round($completion / $ClientWallSeconds, 6)
    } else { $null }
    return [ordered]@{
        name = $Name
        prompt_tokens = $prompt
        cached_tokens = $cached
        computed_tokens = $computed
        completion_tokens = $completion
        finish_reason = $finishReason
        content_sha256 = Get-A3TextSha256 -Text $content
        response_sha256 = if (Test-Path -LiteralPath $ResponsePath) {
            Get-A3FileSha256 -Path $ResponsePath
        } else { $null }
        client_wall_seconds = [Math]::Round($ClientWallSeconds, 6)
        wall_tps_including_ttft = $wallTps
        prefill_seconds = $prefillSeconds
        prefill_tps_computed_only = $prefillTps
        ttft_server_seconds = $ttftSeconds
        decode_server_seconds = $decodeSeconds
        decode_server_tps = $decodeTps
        graph_token_rows = $graphMs.Count
        graph_tps = $graphTps
    }
}

function Get-A3RuntimeEvidence {
    param(
        [Parameter(Mandatory = $true)][AllowEmptyString()][string]$LogText,
        [Parameter(Mandatory = $true)][string]$MonitorCsvPath
    )
    $context = $null
    $contextMatches = [regex]::Matches(
        $LogText,
        'context buffers ([0-9.]+) MiB \(ctx=(\d+), backend=([^,]+), prefill_chunk=(\d+), raw_kv_rows=(\d+), compressed_kv_rows=(\d+)\)')
    if ($contextMatches.Count -gt 0) {
        $m = $contextMatches[$contextMatches.Count - 1]
        $context = [ordered]@{
            reported_mib = [double]$m.Groups[1].Value
            ctx = [int]$m.Groups[2].Value
            backend = $m.Groups[3].Value
            prefill_chunk = [int]$m.Groups[4].Value
            raw_kv_rows = [int]$m.Groups[5].Value
            compressed_kv_rows = [int]$m.Groups[6].Value
        }
    }
    $extract = {
        param([string]$Pattern)
        @([regex]::Matches($LogText, $Pattern) | ForEach-Object { $_.Value })
    }
    $monitor = [ordered]@{
        rows = 0
        gpu_used_mib_min = $null
        gpu_used_mib_max = $null
        gpu_util_pct_mean = $null
        gpu_power_w_mean = $null
        avail_phys_mb_min = $null
    }
    if (Test-Path -LiteralPath $MonitorCsvPath) {
        $rows = @(Import-Csv -LiteralPath $MonitorCsvPath)
        $monitor.rows = $rows.Count
        if ($rows.Count -gt 0) {
            $gpuUsed = @($rows | ForEach-Object { [double]$_.gpu_used_mb } | Where-Object { $_ -ge 0 })
            $gpuUtil = @($rows | ForEach-Object { [double]$_.gpu_util_pct } | Where-Object { $_ -ge 0 })
            $gpuPower = @($rows | ForEach-Object { [double]$_.gpu_power_w } | Where-Object { $_ -ge 0 })
            $avail = @($rows | ForEach-Object { [double]$_.avail_phys_mb } | Where-Object { $_ -ge 0 })
            if ($gpuUsed.Count) {
                $monitor.gpu_used_mib_min = ($gpuUsed | Measure-Object -Minimum).Minimum
                $monitor.gpu_used_mib_max = ($gpuUsed | Measure-Object -Maximum).Maximum
            }
            if ($gpuUtil.Count) {
                $monitor.gpu_util_pct_mean = [Math]::Round(($gpuUtil | Measure-Object -Average).Average, 3)
            }
            if ($gpuPower.Count) {
                $monitor.gpu_power_w_mean = [Math]::Round(($gpuPower | Measure-Object -Average).Average, 3)
            }
            if ($avail.Count) {
                $monitor.avail_phys_mb_min = ($avail | Measure-Object -Minimum).Minimum
            }
        }
    }
    return [ordered]@{
        context = $context
        monitor = $monitor
        staged_kv_lines = & $extract '(?m)^ds4: \[kv-staged\][^\r\n]*$'
        vram_ledger_lines = & $extract '(?m)^ds4: \[vram-ledger\][^\r\n]*$'
        cache_size_lines = & $extract '(?m)^ds4: \[(?:iq2-expert-cache-size|q1-vram-lru)\][^\r\n]*$'
        alloc_summary_lines = & $extract '(?m)^ds4: \[cuda-alloc-(?:summary|balance)\][^\r\n]*$'
        route_final_lines = & $extract '(?m)^ds4: \[gpu-resident-routes\] final[^\r\n]*$'
        preserve_lines = & $extract '(?m)^.*\[prefill-mass-wrap\] result=preserved reason=short-suffix[^\r\n]*$'
        decode_refused_count = [regex]::Matches(
            $LogText, 'decode refused: closed snapshot publication failed').Count
        mailbox_quarantine_count = [regex]::Matches(
            $LogText, 'route-mailbox[^\r\n]*(?:quarant|mismatch|poison)').Count
        route_io_failure_count = [regex]::Matches(
            $LogText, 'route_io_qd_(?:failures|fallbacks)=([1-9]\d*)').Count
        allocation_failure_count = [regex]::Matches(
            $LogText, '(?:CUDA.*alloc.*failed|cuda-alloc-row[^\r\n]*fails=([1-9]\d*))').Count
    }
}

function Get-A3Mean {
    param([object[]]$Values)
    $numbers = @($Values | Where-Object { $null -ne $_ } | ForEach-Object { [double]$_ })
    if ($numbers.Count -eq 0) { return $null }
    return [Math]::Round(($numbers | Measure-Object -Average).Average, 6)
}

function Get-A3ThroughputDeltaPercent {
    param($A, $B)
    if ($null -eq $A -or [double]$A -eq 0 -or $null -eq $B) { return $null }
    return [Math]::Round((([double]$B - [double]$A) / [double]$A) * 100.0, 4)
}

function Get-A3LatencyImprovementPercent {
    param($A, $B)
    if ($null -eq $A -or [double]$A -eq 0 -or $null -eq $B) { return $null }
    return [Math]::Round((([double]$A - [double]$B) / [double]$A) * 100.0, 4)
}
