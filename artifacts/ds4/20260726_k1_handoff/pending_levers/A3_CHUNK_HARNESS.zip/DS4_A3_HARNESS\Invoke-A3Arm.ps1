param(
    [ValidateSet('ValidateOnly', 'Run')]
    [string]$Mode = 'ValidateOnly',
    [ValidateSet('Short', 'Prefill')]
    [string]$Lane = 'Short',
    [ValidateSet(250, 600, 768)]
    [int]$PrefillChunk = 250,
    [ValidateSet('Pending', '0', '1')]
    [string]$G73Open = 'Pending',
    [string]$RunId = '',
    [string]$SourceRoot =
        'C:\Users\imanu\Documents\Codex\2026-07-25\legg\work\wt-hot-reserve',
    [string]$ExePath = '',
    [string]$ModelPath = 'C:\ds4-models\ds4-2bit.gguf',
    [string]$OutputRoot = '',
    [ValidateRange(1024, 65535)]
    [int]$Port = 8000,
    [ValidateRange(1, 1024)]
    [int]$ShortTurn1MaxTokens = 128,
    [ValidateRange(1, 1024)]
    [int]$ShortTurn2MaxTokens = 32,
    [ValidateRange(1, 32)]
    [int]$PrefillMaxTokens = 8
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$invariant = [System.Globalization.CultureInfo]::InvariantCulture
[System.Threading.Thread]::CurrentThread.CurrentCulture = $invariant
[System.Threading.Thread]::CurrentThread.CurrentUICulture = $invariant

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
. (Join-Path $root 'A3.Common.ps1')

if ([string]::IsNullOrWhiteSpace($ExePath)) {
    $ExePath = Join-Path $SourceRoot 'build2\ds4_server.exe'
}
if ([string]::IsNullOrWhiteSpace($OutputRoot)) {
    $OutputRoot = Join-Path $root 'runs'
}
if ([string]::IsNullOrWhiteSpace($RunId)) {
    $safeG73 = $G73Open.ToLowerInvariant()
    $RunId = '{0}_{1}_chunk{2}_g73-{3}_{4}' -f
        (Get-Date -Format 'yyyyMMdd_HHmmss'),
        $Lane.ToLowerInvariant(),
        $PrefillChunk,
        $safeG73,
        ([guid]::NewGuid().ToString('N').Substring(0, 8))
}

$runDirectory = Join-Path $OutputRoot $RunId
New-Item -ItemType Directory -Path $runDirectory -Force | Out-Null
$statusPath = Join-Path $runDirectory 'status.log'
$manifestPath = Join-Path $runDirectory 'manifest_47.effective.env'
$manifestJsonPath = Join-Path $runDirectory 'effective_environment.json'
$provenancePath = Join-Path $runDirectory 'provenance.json'
$geometryPath = Join-Path $runDirectory 'geometry.json'
$receiptPath = Join-Path $runDirectory 'arm_receipt.json'
$serverLog = Join-Path $runDirectory 'server.stderr.log'
$serverStdout = Join-Path $runDirectory 'server.stdout.log'
$monitorCsv = Join-Path $runDirectory 'runtime_monitor.csv'
$monitorStop = Join-Path $runDirectory 'runtime_monitor.stop'
$monitorStdout = Join-Path $runDirectory 'runtime_monitor.stdout.log'
$monitorStderr = Join-Path $runDirectory 'runtime_monitor.stderr.log'
$templatePath = Join-Path $root 'manifest_47.template.env'

$expected = [ordered]@{
    exe_sha256 = 'f2f6a25600ef0b6728be0dae77acfc5ce89abceb1446555a7db946da26f11dff'
    exe_bytes = [UInt64]12412416
    model_sha256 = 'efc7ed607ff27076e3e501fc3fefefa33c0ed8cf1eff483a2b7fdc0c2e616668'
    model_bytes = [UInt64]86720111488
    source = [ordered]@{
        'ds4.c' = '2c2840fca3f1ff7b0c745bf376e04bcb28aed248fdc6de504093d949288415a4'
        'ds4_cuda.cu' = 'feb2954ed2fa583c0631c4fe763b75ffa1f4d0d51598d2ed2ac6f5a87e303496'
        'ds4_gpu.h' = 'eb51fe6f3250ce023803aff77b407ce73bbe004f212f33e2e68638969e9a8e06'
    }
    short_turn1_content_sha256 =
        '7f82253a4825191926f56073e40f10a0cff5541a721731bc81d2909dc1a4a65b'
    short_turn2_content_sha256 =
        '0179556c8e2dbcdc818fad315ca4df78f7537b63816dac276615b314195b13eb'
}

function Write-A3Status {
    param([string]$Message)
    $line = '{0} {1}' -f (Get-Date).ToString('o'), $Message
    Add-Content -LiteralPath $statusPath -Value $line -Encoding ascii
    Write-Output $line
}

function Get-A3ListenerPid {
    try {
        $listener = Get-NetTCPConnection -LocalAddress '127.0.0.1' `
            -LocalPort $Port -State Listen -ErrorAction Stop |
            Select-Object -First 1
        if ($listener) { return [int]$listener.OwningProcess }
    } catch {}
    return 0
}

function Get-A3LogLineCount {
    if (-not (Test-Path -LiteralPath $serverLog)) { return 0 }
    return @(Get-Content -LiteralPath $serverLog).Count
}

function Save-A3LogSlice {
    param([int]$StartLine, [int]$EndLine, [string]$Path)
    $lines = @(Get-Content -LiteralPath $serverLog)
    $count = [Math]::Max(0, $EndLine - $StartLine)
    if ($count -eq 0) {
        Set-Content -LiteralPath $Path -Value '' -Encoding utf8
        return
    }
    @($lines | Select-Object -Skip $StartLine -First $count) |
        Set-Content -LiteralPath $Path -Encoding utf8
}

function Read-A3TextShared {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) { return '' }
    $stream = [System.IO.File]::Open(
        $Path,
        [System.IO.FileMode]::Open,
        [System.IO.FileAccess]::Read,
        [System.IO.FileShare]::ReadWrite -bor [System.IO.FileShare]::Delete)
    $reader = [System.IO.StreamReader]::new(
        $stream, [System.Text.Encoding]::UTF8, $true)
    try { return $reader.ReadToEnd() }
    finally {
        $reader.Dispose()
        $stream.Dispose()
    }
}

function Invoke-A3Request {
    param(
        [Parameter(Mandatory = $true)]$Body,
        [Parameter(Mandatory = $true)][string]$Name
    )
    $requestPath = Join-Path $runDirectory "$Name.request.json"
    $responsePath = Join-Path $runDirectory "$Name.response.json"
    $logPath = Join-Path $runDirectory "$Name.server.log"
    $json = $Body | ConvertTo-Json -Depth 10 -Compress
    [System.IO.File]::WriteAllText(
        $requestPath, $json, [System.Text.UTF8Encoding]::new($false))
    $startLine = Get-A3LogLineCount
    $watch = [System.Diagnostics.Stopwatch]::StartNew()
    $httpCode = & curl.exe -sS --max-time 7200 `
        -X POST "http://127.0.0.1:$Port/v1/chat/completions" `
        -H 'Content-Type: application/json' `
        --data-binary "@$requestPath" `
        -o $responsePath `
        -w '%{http_code}'
    $curlStatus = $LASTEXITCODE
    $watch.Stop()
    if ($curlStatus -ne 0 -or [string]$httpCode -ne '200') {
        throw "$Name request failed: curl=$curlStatus http=$httpCode"
    }
    Start-Sleep -Seconds 1
    $endLine = Get-A3LogLineCount
    Save-A3LogSlice -StartLine $startLine -EndLine $endLine -Path $logPath
    return [pscustomobject]@{
        name = $Name
        request_path = $requestPath
        response_path = $responsePath
        log_path = $logPath
        elapsed_seconds = $watch.Elapsed.TotalSeconds
        response = [System.IO.File]::ReadAllText(
            $responsePath, [System.Text.Encoding]::UTF8) | ConvertFrom-Json
    }
}

$manifest = New-A3EffectiveManifest `
    -TemplatePath $templatePath `
    -PrefillChunk $PrefillChunk `
    -G73Open $G73Open
$geometry = Get-A3Geometry -PrefillChunk $PrefillChunk
[System.IO.File]::WriteAllText(
    $manifestPath,
    $manifest.CanonicalText,
    [System.Text.ASCIIEncoding]::new())
Write-A3Json -Value $geometry -Path $geometryPath

$observedSource = [ordered]@{}
$sourceHashPass = $true
foreach ($name in $expected.source.Keys) {
    $path = Join-Path $SourceRoot $name
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        $observedSource[$name] = $null
        $sourceHashPass = $false
    } else {
        $hash = Get-A3FileSha256 -Path $path
        $observedSource[$name] = $hash
        if ($hash -ne [string]$expected.source[$name]) { $sourceHashPass = $false }
    }
}
$exeExists = Test-Path -LiteralPath $ExePath -PathType Leaf
$exeHash = if ($exeExists) { Get-A3FileSha256 -Path $ExePath } else { $null }
$exeBytes = if ($exeExists) { [UInt64](Get-Item -LiteralPath $ExePath).Length } else { 0 }
$modelExists = Test-Path -LiteralPath $ModelPath -PathType Leaf
$modelBytes = if ($modelExists) { [UInt64](Get-Item -LiteralPath $ModelPath).Length } else { 0 }
$binaryModelPass =
    $exeExists -and
    $exeHash -eq $expected.exe_sha256 -and
    $exeBytes -eq $expected.exe_bytes -and
    $modelExists -and
    $modelBytes -eq $expected.model_bytes
$identityPass = $sourceHashPass -and $binaryModelPass

$harnessFiles = [ordered]@{}
foreach ($name in @(
    'A3.Common.ps1',
    'A3.RuntimeMonitor.ps1',
    'Invoke-A3Arm.ps1',
    'manifest_47.template.env')) {
    $path = Join-Path $root $name
    $harnessFiles[$name] = Get-A3FileSha256 -Path $path
}
$provenance = [ordered]@{
    schema = 'ds4_a3_provenance_v1'
    generated_utc = (Get-Date).ToUniversalTime().ToString('o')
    source_root = $SourceRoot
    source_sha256 = $observedSource
    executable_path = $ExePath
    executable_sha256 = $exeHash
    executable_bytes = $exeBytes
    model_path = $ModelPath
    model_bytes = $modelBytes
    model_sha256_expected_receipt = $expected.model_sha256
    model_sha256_verification = 'known-receipt-plus-byte-size; full 86.7GB rehash not repeated per arm'
    harness_sha256 = $harnessFiles
    binary_model_gate_pass = $binaryModelPass
    source_build_receipt_gate_pass = $sourceHashPass
    identity_gate_pass = $identityPass
}
Write-A3Json -Value $provenance -Path $provenancePath

$overlay = [ordered]@{
    DS4_METAL_GRAPH_RAW_CAP = '<UNSET>'
    DS4_CUDA_GRAPH_TENSOR_DEVICE = '<UNSET>'
    DS4_CUDA_MOE_ROUTE_PACKED_COPY = '<UNSET>'
    DS4_CUDA_MOE_ROUTE_BATCHED_PUBLISH = '<UNSET>'
    DS4_CUDA_G73_REUSE_HOST_SELECTED = '<UNSET>'
    DS4_CUDA_G73_ROUTE_IO_QD = '<UNSET>'
    DS4_CUDA_ALLOC_TRACE = '1'
    DS4_CUDA_ALLOC_TRACE_MIN_MIB = '1048576'
    DS4_REQUEST_PHASE_TRACE = '1'
}
$manifestReceipt = [ordered]@{
    schema = 'ds4_a3_effective_environment_v1'
    base_count = 47
    base_sha256 = $manifest.Sha256
    non_treatment_sha256 = $manifest.NonTreatmentSha256
    base = $manifest.Values
    instrumentation_and_unset_controls = $overlay
    treatment_only_difference = 'DS4_METAL_PREFILL_CHUNK'
    g73_source = if ($G73Open -eq 'Pending') { 'PENDING_A2' } else { 'explicit_parameter' }
}
Write-A3Json -Value $manifestReceipt -Path $manifestJsonPath

$prefillPrompt = Get-A3LongPrefillPrompt
$promptReceipt = [ordered]@{
    short_turn1_utf8 = 'Ciao, sai fare un bel sito?'
    short_turn2_utf8 = 'Fammi una landing page minimal, single-file HTML, molto breve.'
    prefill_prompt_utf8_sha256 = Get-A3TextSha256 -Text $prefillPrompt
    prefill_prompt_utf8_bytes = [System.Text.UTF8Encoding]::new($false).GetByteCount($prefillPrompt)
    prefill_min_computed_tokens_gate = 601
}

if ($Mode -eq 'ValidateOnly') {
    # Harness validation is deliberately independent from mutable external
    # source state. A drifted source receipt is recorded and blocks Run below,
    # but it must not make parser/manifest/geometry validation look broken.
    $validationPass = $manifest.Lines.Count -eq 47
    $receipt = [ordered]@{
        schema = 'ds4_a3_arm_receipt_v1'
        status = if ($validationPass) { 'VALIDATED_ONLY' } else { 'VALIDATION_FAILED' }
        server_started = $false
        run_eligible = [bool]$manifest.RunEligible
        external_identity_ready = $identityPass
        pending_reason = if ($manifest.RunEligible) { $null } else { 'G73 winner must be supplied by A2' }
        run_id = $RunId
        lane = $Lane
        treatment = [ordered]@{
            prefill_chunk = $PrefillChunk
            g73_open = $G73Open
            ctx_capacity = 150000
        }
        geometry = $geometry
        manifest = [ordered]@{
            count = 47
            sha256 = $manifest.Sha256
            non_treatment_sha256 = $manifest.NonTreatmentSha256
            path = $manifestPath
        }
        provenance = $provenance
        prompt = $promptReceipt
        gates = [ordered]@{
            syntax_external = 'not evaluated by arm; use Test-A3Harness.ps1'
            identity = $identityPass
            binary_model_identity = $binaryModelPass
            source_build_receipt_identity = $sourceHashPass
            manifest_47 = $manifest.Lines.Count -eq 47
            raw_cap_unset = $true
            no_server = $true
        }
    }
    Write-A3Json -Value $receipt -Path $receiptPath
    Write-A3Status "validation=$($receipt.status) lane=$Lane chunk=$PrefillChunk g73=$G73Open server_started=no"
    Write-Output "A3_RECEIPT=$receiptPath"
    if (-not $validationPass) { exit 2 }
    exit 0
}

if (-not $manifest.RunEligible) {
    throw 'Run is blocked: supply -G73Open 0 or 1 from the completed A2 result'
}
if (-not $identityPass) {
    throw 'Run is blocked: source/executable/model identity gate failed'
}

$existingServers = @(Get-Process ds4_server -ErrorAction SilentlyContinue)
$listenerPid = Get-A3ListenerPid
if ($existingServers.Count -ne 0 -or $listenerPid -gt 0) {
    throw "dirty preflight: ds4_server=$($existingServers.Count) listener_pid=$listenerPid"
}
Add-Type -AssemblyName Microsoft.VisualBasic
$memoryInfo = New-Object Microsoft.VisualBasic.Devices.ComputerInfo
$availableGiB = $memoryInfo.AvailablePhysicalMemory / 1GB
$gpuText = & nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits 2>$null |
    Select-Object -First 1
if ($gpuText -notmatch '^\s*([0-9]+)') { throw 'cannot read GPU memory usage' }
$gpuUsedMiB = [int]$matches[1]
if ($availableGiB -lt 28 -or $gpuUsedMiB -ge 1200) {
    throw ('preflight resource gate failed: RAM={0:F2}GiB GPU={1}MiB' -f
        $availableGiB, $gpuUsedMiB)
}

$savedDs4 = [ordered]@{}
foreach ($item in Get-ChildItem Env: | Where-Object Name -Like 'DS4_*') {
    $savedDs4[$item.Name] = [string]$item.Value
}
foreach ($item in Get-ChildItem Env: | Where-Object Name -Like 'DS4_*') {
    Remove-Item -LiteralPath "Env:$($item.Name)"
}
foreach ($entry in $manifest.Values.GetEnumerator()) {
    Set-Item -LiteralPath "Env:$($entry.Key)" -Value ([string]$entry.Value)
}
$env:DS4_CUDA_ALLOC_TRACE = '1'
$env:DS4_CUDA_ALLOC_TRACE_MIN_MIB = '1048576'
$env:DS4_REQUEST_PHASE_TRACE = '1'

$shutdownBytes = New-Object byte[] 32
$rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
$rng.GetBytes($shutdownBytes)
$rng.Dispose()
$shutdownToken = ([BitConverter]::ToString($shutdownBytes) -replace '-', '').ToLowerInvariant()
$env:DS4_G130_U1_SHUTDOWN_TOKEN = $shutdownToken

$serverArgs = @(
    '-m', $ModelPath,
    '--cuda',
    '-c', '150000',
    '-n', '8192',
    '--mtp-draft', '1',
    '--host', '127.0.0.1',
    '--port', [string]$Port
)
$server = $null
$monitor = $null
$ds4Pid = 0
$shutdownMode = 'not_started'
$runError = $null
$requestReceipts = @()

try {
    $server = Start-Process -FilePath $ExePath `
        -ArgumentList $serverArgs `
        -WindowStyle Hidden `
        -RedirectStandardOutput $serverStdout `
        -RedirectStandardError $serverLog `
        -PassThru
    Write-A3Status "launcher_started pid=$($server.Id)"
    $ready = $false
    for ($attempt = 1; $attempt -le 900; $attempt++) {
        if ($server.HasExited) { break }
        & curl.exe -s --max-time 2 "http://127.0.0.1:$Port/health" -o NUL 2>$null
        if ($LASTEXITCODE -eq 0) {
            $ready = $true
            break
        }
        Start-Sleep -Seconds 1
    }
    if (-not $ready) { throw "server readiness failed after $attempt attempts" }
    $ds4Pid = Get-A3ListenerPid
    if ($ds4Pid -le 0) { throw 'server ready but listener PID was not found' }
    $monitorArgs = @(
        '-NoProfile',
        '-ExecutionPolicy', 'Bypass',
        '-File', "`"$(Join-Path $root 'A3.RuntimeMonitor.ps1')`"",
        '-ServerPid', [string]$ds4Pid,
        '-CsvPath', "`"$monitorCsv`"",
        '-StopPath', "`"$monitorStop`"",
        '-SampleSeconds', '5'
    ) -join ' '
    $monitor = Start-Process -FilePath 'powershell.exe' `
        -ArgumentList $monitorArgs `
        -WindowStyle Hidden `
        -RedirectStandardOutput $monitorStdout `
        -RedirectStandardError $monitorStderr `
        -PassThru

    if ($Lane -eq 'Short') {
        $turn1Body = [ordered]@{
            model = 'ds4'
            think = $false
            max_tokens = $ShortTurn1MaxTokens
            temperature = 0.7
            seed = 12345
            messages = @(
                [ordered]@{ role = 'user'; content = 'Ciao, sai fare un bel sito?' }
            )
        }
        $turn1 = Invoke-A3Request -Body $turn1Body -Name 'short_turn1'
        $assistant = [string]$turn1.response.choices[0].message.content
        if ([string]::IsNullOrWhiteSpace($assistant)) {
            throw 'short turn1 returned empty assistant content'
        }
        $turn2Body = [ordered]@{
            model = 'ds4'
            think = $false
            max_tokens = $ShortTurn2MaxTokens
            temperature = 0.7
            seed = 12345
            messages = @(
                [ordered]@{ role = 'user'; content = 'Ciao, sai fare un bel sito?' },
                [ordered]@{ role = 'assistant'; content = $assistant },
                [ordered]@{
                    role = 'user'
                    content = 'Fammi una landing page minimal, single-file HTML, molto breve.'
                }
            )
        }
        $turn2 = Invoke-A3Request -Body $turn2Body -Name 'short_turn2'
        $requestReceipts = @($turn1, $turn2)
    } else {
        $prefillBody = [ordered]@{
            model = 'ds4'
            think = $false
            max_tokens = $PrefillMaxTokens
            temperature = 0.7
            seed = 12345
            messages = @(
                [ordered]@{ role = 'user'; content = $prefillPrompt }
            )
        }
        $prefill = Invoke-A3Request -Body $prefillBody -Name 'prefill_gt600'
        $requestReceipts = @($prefill)
    }
} catch {
    $runError = $_.Exception.Message
    Write-A3Status "run_error=$runError"
} finally {
    New-Item -ItemType File -Path $monitorStop -Force | Out-Null
    if ($monitor -and -not $monitor.HasExited) {
        $null = $monitor.WaitForExit(10000)
        if (-not $monitor.HasExited) {
            Stop-Process -Id $monitor.Id -Force -ErrorAction SilentlyContinue
        }
    }
    if ($server) {
        try {
            $currentPid = Get-A3ListenerPid
            if ($ds4Pid -le 0 -and $currentPid -gt 0) { $ds4Pid = $currentPid }
            $alive = $ds4Pid -gt 0 -and
                $null -ne (Get-Process -Id $ds4Pid -ErrorAction SilentlyContinue)
            if ($alive -or (Get-A3ListenerPid) -gt 0) {
                $body = '{"token":"' + $shutdownToken + '"}'
                Invoke-RestMethod -Method Post `
                    -Uri "http://127.0.0.1:$Port/__g130_u1_shutdown" `
                    -ContentType 'application/json' `
                    -Body $body `
                    -TimeoutSec 10 | Out-Null
                $watch = [System.Diagnostics.Stopwatch]::StartNew()
                do {
                    $alive = $ds4Pid -gt 0 -and
                        $null -ne (Get-Process -Id $ds4Pid -ErrorAction SilentlyContinue)
                    $portAlive = (Get-A3ListenerPid) -gt 0
                    if (-not $alive -and -not $portAlive) { break }
                    Start-Sleep -Milliseconds 250
                } while ($watch.Elapsed.TotalSeconds -lt 120)
                if ($alive -or $portAlive) {
                    if ($ds4Pid -gt 0) {
                        Stop-Process -Id $ds4Pid -Force -ErrorAction SilentlyContinue
                    }
                    $shutdownMode = 'forced_after_grace_timeout'
                } else {
                    $shutdownMode = 'graceful_http_verified'
                }
            } else {
                $shutdownMode = 'already_exited'
            }
            $server.Refresh()
            if (-not $server.HasExited) { $null = $server.WaitForExit(30000) }
            if (-not $server.HasExited) {
                Stop-Process -Id $server.Id -Force -ErrorAction SilentlyContinue
                $shutdownMode = 'launcher_forced'
            }
        } catch {
            if ($ds4Pid -gt 0) {
                Stop-Process -Id $ds4Pid -Force -ErrorAction SilentlyContinue
            }
            $server.Refresh()
            if (-not $server.HasExited) {
                Stop-Process -Id $server.Id -Force -ErrorAction SilentlyContinue
            }
            $shutdownMode = 'forced_after_shutdown_error'
            if (-not $runError) { $runError = "shutdown: $($_.Exception.Message)" }
        }
    }
    foreach ($item in Get-ChildItem Env: | Where-Object Name -Like 'DS4_*') {
        Remove-Item -LiteralPath "Env:$($item.Name)"
    }
    foreach ($entry in $savedDs4.GetEnumerator()) {
        Set-Item -LiteralPath "Env:$($entry.Key)" -Value ([string]$entry.Value)
    }
}

$allLog = Read-A3TextShared -Path $serverLog
$metrics = @()
foreach ($request in $requestReceipts) {
    $logText = Read-A3TextShared -Path $request.log_path
    $metrics += [pscustomobject](Get-A3RequestMetrics `
        -LogText $logText `
        -ResponsePath $request.response_path `
        -ClientWallSeconds $request.elapsed_seconds `
        -Name $request.name)
}
$runtime = Get-A3RuntimeEvidence -LogText $allLog -MonitorCsvPath $monitorCsv
$geometryGate =
    $null -ne $runtime.context -and
    [int]$runtime.context.ctx -eq 150000 -and
    [int]$runtime.context.prefill_chunk -eq $PrefillChunk -and
    [int]$runtime.context.raw_kv_rows -eq [int]$geometry.expected_raw_rows
$commonGate =
    -not $runError -and
    $geometryGate -and
    $runtime.decode_refused_count -eq 0 -and
    $runtime.mailbox_quarantine_count -eq 0 -and
    $runtime.route_io_failure_count -eq 0 -and
    $runtime.allocation_failure_count -eq 0 -and
    $shutdownMode -eq 'graceful_http_verified'

$laneGate = $false
$laneGateDetail = [ordered]@{}
if ($Lane -eq 'Short' -and $metrics.Count -eq 2) {
    $turn1Metric = $metrics[0]
    $turn2Metric = $metrics[1]
    $preserve = if ($runtime.preserve_lines.Count -gt 0) {
        [string]$runtime.preserve_lines[$runtime.preserve_lines.Count - 1]
    } else { '' }
    $snapshotUnchanged = $preserve -match
        'snapshot_before=(\d+).*snapshot_after=\1'
    $residentUnchanged = $preserve -match
        'resident_before=(\d+).*resident_after=\1'
    $laneGateDetail = [ordered]@{
        turn1_exact = $turn1Metric.content_sha256 -eq $expected.short_turn1_content_sha256
        turn2_exact = $turn2Metric.content_sha256 -eq $expected.short_turn2_content_sha256
        turn2_cached_positive = $turn2Metric.cached_tokens -gt 0
        turn2_computed_positive_below_32 =
            $turn2Metric.computed_tokens -gt 0 -and $turn2Metric.computed_tokens -lt 32
        snapshot_unchanged = $snapshotUnchanged
        resident_unchanged = $residentUnchanged
    }
    $laneGate = -not ($laneGateDetail.Values -contains $false)
}
if ($Lane -eq 'Prefill' -and $metrics.Count -eq 1) {
    $prefillMetric = $metrics[0]
    $laneGateDetail = [ordered]@{
        cached_zero = $prefillMetric.cached_tokens -eq 0
        computed_above_600 = $prefillMetric.computed_tokens -gt 600
        prefill_tps_present = $null -ne $prefillMetric.prefill_tps_computed_only
        ttft_present = $null -ne $prefillMetric.ttft_server_seconds
        output_hash_present = $prefillMetric.content_sha256 -match '^[0-9a-f]{64}$'
    }
    $laneGate = -not ($laneGateDetail.Values -contains $false)
}
$gatePass = $identityPass -and $commonGate -and $laneGate

$receipt = [ordered]@{
    schema = 'ds4_a3_arm_receipt_v1'
    status = if ($gatePass) { 'PASS' } else { 'FAIL' }
    server_started = $true
    run_eligible = $true
    run_id = $RunId
    lane = $Lane
    treatment = [ordered]@{
        prefill_chunk = $PrefillChunk
        g73_open = $G73Open
        ctx_capacity = 150000
    }
    geometry = $geometry
    manifest = [ordered]@{
        count = 47
        sha256 = $manifest.Sha256
        non_treatment_sha256 = $manifest.NonTreatmentSha256
        path = $manifestPath
    }
    provenance = $provenance
    prompt = $promptReceipt
    requests = $metrics
    runtime = $runtime
    shutdown_mode = $shutdownMode
    run_error = $runError
    gates = [ordered]@{
        identity = $identityPass
        manifest_47 = $manifest.Lines.Count -eq 47
        geometry = $geometryGate
        common_runtime = $commonGate
        lane = $laneGate
        lane_detail = $laneGateDetail
        overall = $gatePass
    }
}
Write-A3Json -Value $receipt -Path $receiptPath
Write-A3Status "gate=$gatePass lane=$Lane chunk=$PrefillChunk g73=$G73Open shutdown=$shutdownMode"
Write-Output "A3_RECEIPT=$receiptPath"
if (-not $gatePass) { exit 2 }
