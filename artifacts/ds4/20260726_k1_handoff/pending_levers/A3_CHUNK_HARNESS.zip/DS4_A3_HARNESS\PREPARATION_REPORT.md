# A3 harness preparation receipt

Date: 2026-07-26  
Scope: preparation and validation only.  
DS4 executions by this harness: **0**.  
Shared runner/repository writes: **0**.

## Result

```text
HARNESS_READY=yes
RUN_READY=no
```

The standalone bundle implements:

- `PrefillChunk=250|600|768`;
- `G73Open=Pending|0|1`, with fail-closed `Run` while Pending;
- rendered effective manifest with exactly 47 unique base variables;
- provenance for executable, source files, model receipt and harness;
- theoretical allocation/raw-row geometry and observed context/raw-row gates;
- independent cold-process `Short` and `Prefill` lanes;
- ABBA ordering for both lanes: eight independent server processes when Run is
  eventually authorized;
- prompt/cached/computed/completion, prefill t/s, TTFT, decode server t/s,
  graph t/s and wall t/s kept separate;
- output, snapshot, staged-KV, cache-sizing, allocation, route, shutdown and
  postflight evidence;
- same-identity/non-treatment manifest gate in the campaign summarizer;
- `<10%=variance` and a fail-closed condition for adding 768.

## Static/ValidateOnly evidence

`Test-A3Harness.ps1` passed:

- PowerShell parser: 6/6 scripts;
- manifest: 47/47 for 250, 600 and 768;
- raw rows: 512, 768 and 1024;
- prefill fixture: more than 600 words, plus runtime
  `computed_tokens > 600` gate;
- ValidateOnly branch occurs before server `Start-Process`;
- per-arm ValidateOnly for 250/600/768, all `server_started=false`;
- ABBA ValidateOnly: eight receipts and `VALIDATED_ONLY`;
- synthetic real-summary path: PASS, separate prefill/decode deltas and expected
  `add_768=true` for the +20% fixture.

Authoritative validation receipt:
`_validation/static_validation.json`.

## External blockers

1. A2 has not supplied the winning `G73_OPEN` value.
2. The executable still matches the documented build:
   `f2f6a25600ef0b6728be0dae77acfc5ce89abceb1446555a7db946da26f11dff`,
   but the shared source files changed after that build receipt:

```text
file          documented build SHA256                    observed SHA256
ds4.c         2c2840...415a4                             54f5e1...c8466
ds4_cuda.cu   feb295...03496                             53b152...4182
ds4_gpu.h     eb51fe...9a8e06                            625f47...d436c
```

The harness distinguishes its own readiness from external identity readiness.
`Run` remains blocked until this source/build provenance is reconciled.

## No-run note

All generated arm receipts state `server_started=false`. A separate
`ds4_server.exe` from `build-a1-graph-tensor-device` appeared after the static
validation completed; its process start time is later than the validation
receipt and it was not started, used or stopped by this harness.

## Merge

The bundle is directly usable outside the shared repository. If later merged,
follow `README.md`:

1. add parameters without selecting G73;
2. substitute manifest rows 41/44 while keeping 47/47;
3. port receipt/geometry parsing;
4. retain the pre-`Start-Process` ValidateOnly exit;
5. keep Short and Prefill in separate cold processes;
6. retain same-binary and `<10%=variance` gates;
7. review and rerun static validation before authorizing a run.
