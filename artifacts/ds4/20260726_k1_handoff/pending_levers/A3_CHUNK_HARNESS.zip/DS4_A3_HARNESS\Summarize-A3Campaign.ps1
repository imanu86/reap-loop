param(
    [Parameter(Mandatory = $true)]
    [string]$CampaignDirectory,
    [ValidateSet(250, 600, 768)]
    [int]$ArmAChunk = 250,
    [ValidateSet(250, 600, 768)]
    [int]$ArmBChunk = 600
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
. (Join-Path $root 'A3.Common.ps1')

if ($ArmAChunk -eq $ArmBChunk) { throw 'A and B chunks must differ' }
$receiptFiles = @(
    Get-ChildItem -LiteralPath $CampaignDirectory `
        -Recurse -Filter 'arm_receipt.json' -File
)
if ($receiptFiles.Count -eq 0) {
    throw "no arm receipts found in $CampaignDirectory"
}
$receipts = @(
    $receiptFiles |
        ForEach-Object {
            [System.IO.File]::ReadAllText(
                $_.FullName, [System.Text.Encoding]::UTF8) | ConvertFrom-Json
        }
)
$validationOnly = @($receipts | Where-Object status -eq 'VALIDATED_ONLY').Count -eq
    $receipts.Count
$expectedChunks = @($ArmAChunk, $ArmBChunk)
$unexpected = @(
    $receipts |
        Where-Object { [int]$_.treatment.prefill_chunk -notin $expectedChunks }
)
if ($unexpected.Count -ne 0) { throw 'campaign contains an unexpected chunk' }

$identityTuples = @(
    $receipts | ForEach-Object {
        '{0}|{1}|{2}|{3}|{4}' -f
            $_.provenance.executable_sha256,
            $_.provenance.model_sha256_expected_receipt,
            $_.provenance.source_sha256.'ds4.c',
            $_.provenance.source_sha256.'ds4_cuda.cu',
            $_.provenance.source_sha256.'ds4_gpu.h'
    } | Select-Object -Unique
)
$nonTreatmentHashes = @(
    $receipts |
        ForEach-Object { [string]$_.manifest.non_treatment_sha256 } |
        Select-Object -Unique
)
$g73Values = @(
    $receipts |
        ForEach-Object { [string]$_.treatment.g73_open } |
        Select-Object -Unique
)
$manifestCounts = @(
    $receipts |
        Where-Object { [int]$_.manifest.count -ne 47 }
)
$geometryFailures = @(
    $receipts |
        Where-Object {
            $expectedRaw = if ([int]$_.treatment.prefill_chunk -eq 250) {
                512
            } elseif ([int]$_.treatment.prefill_chunk -eq 600) {
                768
            } else {
                1024
            }
            [int]$_.geometry.expected_raw_rows -ne $expectedRaw
        }
)
$provenanceGate =
    $identityTuples.Count -eq 1 -and
    $nonTreatmentHashes.Count -eq 1 -and
    $g73Values.Count -eq 1 -and
    $manifestCounts.Count -eq 0 -and
    $geometryFailures.Count -eq 0

$summary = [ordered]@{
    schema = 'ds4_a3_campaign_summary_v1'
    generated_utc = (Get-Date).ToUniversalTime().ToString('o')
    campaign_directory = $CampaignDirectory
    arm_a_chunk = $ArmAChunk
    arm_b_chunk = $ArmBChunk
    receipt_count = $receipts.Count
    validation_only = $validationOnly
    provenance_gate_pass = $provenanceGate
    identity_tuple_count = $identityTuples.Count
    non_treatment_manifest_count = $nonTreatmentHashes.Count
    g73_values = $g73Values
    metrics = $null
    exact_output_gate_pass = $null
    arm_runtime_gate_pass = $null
    delta_rule = 'absolute mean delta below 10 percent is variance'
    add_768 = $false
    status = 'FAIL'
}

if ($validationOnly) {
    $allManifest = @(
        $receipts | Where-Object { -not [bool]$_.gates.manifest_47 }
    ).Count -eq 0
    $allIdentity = @(
        $receipts | Where-Object { -not [bool]$_.gates.identity }
    ).Count -eq 0
    $allNoServer = @(
        $receipts | Where-Object { [bool]$_.server_started }
    ).Count -eq 0
    $summary.status = if (
        $provenanceGate -and $allManifest -and $allNoServer -and
        $receipts.Count -eq 8
    ) { 'VALIDATED_ONLY' } else { 'VALIDATION_FAILED' }
    $summary.harness_ready = $summary.status -eq 'VALIDATED_ONLY'
    $summary.external_identity_ready = $allIdentity
    $summary.run_ready = $summary.harness_ready -and $allIdentity -and
        $g73Values.Count -eq 1 -and $g73Values[0] -in @('0', '1')
    $summary.pending_reason = if ($summary.run_ready) {
        $null
    } elseif (-not $allIdentity) {
        'external source/build receipt drift must be reconciled before Run'
    } else {
        'G73 winner is still Pending and must come from A2'
    }
} else {
    $runtimeGate = @(
        $receipts |
            Where-Object { $_.status -ne 'PASS' -or -not [bool]$_.gates.overall }
    ).Count -eq 0
    $shortReceipts = @($receipts | Where-Object lane -eq 'Short')
    $prefillReceipts = @($receipts | Where-Object lane -eq 'Prefill')
    $shortA = @($shortReceipts | Where-Object { [int]$_.treatment.prefill_chunk -eq $ArmAChunk })
    $shortB = @($shortReceipts | Where-Object { [int]$_.treatment.prefill_chunk -eq $ArmBChunk })
    $prefillA = @($prefillReceipts | Where-Object { [int]$_.treatment.prefill_chunk -eq $ArmAChunk })
    $prefillB = @($prefillReceipts | Where-Object { [int]$_.treatment.prefill_chunk -eq $ArmBChunk })
    $replicationGate =
        $shortA.Count -eq 2 -and $shortB.Count -eq 2 -and
        $prefillA.Count -eq 2 -and $prefillB.Count -eq 2
    $shortTurn1Hashes = @(
        $shortReceipts | ForEach-Object { [string]$_.requests[0].content_sha256 } |
            Select-Object -Unique
    )
    $shortTurn2Hashes = @(
        $shortReceipts | ForEach-Object { [string]$_.requests[1].content_sha256 } |
            Select-Object -Unique
    )
    $prefillHashes = @(
        $prefillReceipts | ForEach-Object { [string]$_.requests[0].content_sha256 } |
            Select-Object -Unique
    )
    $exactGate =
        $shortTurn1Hashes.Count -eq 1 -and
        $shortTurn2Hashes.Count -eq 1 -and
        $prefillHashes.Count -eq 1

    $aShortGraph = Get-A3Mean @($shortA | ForEach-Object { $_.requests[0].graph_tps })
    $bShortGraph = Get-A3Mean @($shortB | ForEach-Object { $_.requests[0].graph_tps })
    $aShortDecode = Get-A3Mean @($shortA | ForEach-Object { $_.requests[0].decode_server_tps })
    $bShortDecode = Get-A3Mean @($shortB | ForEach-Object { $_.requests[0].decode_server_tps })
    $aShortWall = Get-A3Mean @($shortA | ForEach-Object { $_.requests[0].wall_tps_including_ttft })
    $bShortWall = Get-A3Mean @($shortB | ForEach-Object { $_.requests[0].wall_tps_including_ttft })
    $aShortTtft = Get-A3Mean @($shortA | ForEach-Object { $_.requests[0].ttft_server_seconds })
    $bShortTtft = Get-A3Mean @($shortB | ForEach-Object { $_.requests[0].ttft_server_seconds })
    $aPrefill = Get-A3Mean @($prefillA | ForEach-Object { $_.requests[0].prefill_tps_computed_only })
    $bPrefill = Get-A3Mean @($prefillB | ForEach-Object { $_.requests[0].prefill_tps_computed_only })
    $aPrefillTtft = Get-A3Mean @($prefillA | ForEach-Object { $_.requests[0].ttft_server_seconds })
    $bPrefillTtft = Get-A3Mean @($prefillB | ForEach-Object { $_.requests[0].ttft_server_seconds })

    $dShortGraph = Get-A3ThroughputDeltaPercent $aShortGraph $bShortGraph
    $dShortDecode = Get-A3ThroughputDeltaPercent $aShortDecode $bShortDecode
    $dShortWall = Get-A3ThroughputDeltaPercent $aShortWall $bShortWall
    $dShortTtft = Get-A3LatencyImprovementPercent $aShortTtft $bShortTtft
    $dPrefill = Get-A3ThroughputDeltaPercent $aPrefill $bPrefill
    $dPrefillTtft = Get-A3LatencyImprovementPercent $aPrefillTtft $bPrefillTtft
    $deltas = @($dShortGraph, $dShortDecode, $dShortWall, $dShortTtft, $dPrefill, $dPrefillTtft)
    $useful = @($deltas | Where-Object { $null -ne $_ -and [double]$_ -ge 10 }).Count -gt 0
    $noRegression = @($deltas | Where-Object { $null -ne $_ -and [double]$_ -le -10 }).Count -eq 0
    $campaignPass = $provenanceGate -and $runtimeGate -and $replicationGate -and $exactGate

    $summary.metrics = [ordered]@{
        short_turn1_graph_tps = [ordered]@{
            arm_a_mean = $aShortGraph; arm_b_mean = $bShortGraph; delta_percent = $dShortGraph
        }
        short_turn1_decode_server_tps = [ordered]@{
            arm_a_mean = $aShortDecode; arm_b_mean = $bShortDecode; delta_percent = $dShortDecode
        }
        short_turn1_wall_tps_including_ttft = [ordered]@{
            arm_a_mean = $aShortWall; arm_b_mean = $bShortWall; delta_percent = $dShortWall
        }
        short_turn1_ttft = [ordered]@{
            arm_a_mean = $aShortTtft; arm_b_mean = $bShortTtft
            improvement_percent = $dShortTtft
        }
        prefill_computed_only_tps = [ordered]@{
            arm_a_mean = $aPrefill; arm_b_mean = $bPrefill; delta_percent = $dPrefill
        }
        prefill_ttft = [ordered]@{
            arm_a_mean = $aPrefillTtft; arm_b_mean = $bPrefillTtft
            improvement_percent = $dPrefillTtft
        }
    }
    $summary.exact_output_gate_pass = $exactGate
    $summary.arm_runtime_gate_pass = $runtimeGate
    $summary.replication_gate_pass = $replicationGate
    $summary.status = if ($campaignPass) { 'PASS' } else { 'FAIL' }
    $summary.add_768 = $campaignPass -and $useful -and $noRegression
    $summary.add_768_reason = if (-not $campaignPass) {
        'campaign gates failed'
    } elseif (-not $useful) {
        'no primary mean improvement reached 10 percent'
    } elseif (-not $noRegression) {
        'at least one primary metric regressed by 10 percent or more'
    } else {
        '600 reached the usefulness gate without a primary regression'
    }
}

$summaryPath = Join-Path $CampaignDirectory 'campaign_summary.json'
Write-A3Json -Value $summary -Path $summaryPath
Write-Output "A3_SUMMARY=$summaryPath"
if ($summary.status -in @('FAIL', 'VALIDATION_FAILED')) { exit 2 }
