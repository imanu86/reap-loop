param(
    [string]$ValidationRoot = ''
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
. (Join-Path $root 'A3.Common.ps1')

if ([string]::IsNullOrWhiteSpace($ValidationRoot)) {
    $ValidationRoot = Join-Path $root '_validation'
}
New-Item -ItemType Directory -Path $ValidationRoot -Force | Out-Null
$checks = [ordered]@{}

$scripts = @(
    'A3.Common.ps1',
    'A3.RuntimeMonitor.ps1',
    'Invoke-A3Arm.ps1',
    'Invoke-A3ABBA.ps1',
    'Summarize-A3Campaign.ps1',
    'Test-A3Harness.ps1'
)
foreach ($name in $scripts) {
    $path = Join-Path $root $name
    $tokens = $null
    $errors = $null
    [void][System.Management.Automation.Language.Parser]::ParseFile(
        $path, [ref]$tokens, [ref]$errors)
    $checks["syntax_$name"] = $errors.Count -eq 0
    if ($errors.Count -ne 0) {
        throw "PowerShell syntax failed for $name`: $($errors[0].Message)"
    }
}

$template = Join-Path $root 'manifest_47.template.env'
foreach ($chunk in @(250, 600, 768)) {
    $manifest = New-A3EffectiveManifest `
        -TemplatePath $template `
        -PrefillChunk $chunk `
        -G73Open Pending
    $geometry = Get-A3Geometry -PrefillChunk $chunk
    $expectedRaw = if ($chunk -eq 250) { 512 } elseif ($chunk -eq 600) { 768 } else { 1024 }
    $checks["manifest_47_chunk_$chunk"] = $manifest.Lines.Count -eq 47
    $checks["raw_rows_chunk_$chunk"] = $geometry.expected_raw_rows -eq $expectedRaw
    if (-not $checks["manifest_47_chunk_$chunk"] -or -not $checks["raw_rows_chunk_$chunk"]) {
        throw "manifest/geometry static check failed for chunk $chunk"
    }
}
$prompt = Get-A3LongPrefillPrompt
$promptWords = @($prompt -split '\s+' | Where-Object { $_ }).Count
$checks.prefill_fixture_words_above_600 = $promptWords -gt 600
if (-not $checks.prefill_fixture_words_above_600) {
    throw "prefill fixture is too short: $promptWords words"
}

$armText = [System.IO.File]::ReadAllText(
    (Join-Path $root 'Invoke-A3Arm.ps1'), [System.Text.Encoding]::UTF8)
$validateIndex = $armText.IndexOf("if (`$Mode -eq 'ValidateOnly')")
$startIndex = $armText.IndexOf('Start-Process -FilePath $ExePath')
$checks.validate_exit_precedes_server_start =
    $validateIndex -ge 0 -and $startIndex -gt $validateIndex
if (-not $checks.validate_exit_precedes_server_start) {
    throw 'ValidateOnly branch does not precede server Start-Process'
}

$powershell = Join-Path $PSHOME 'powershell.exe'
$armScript = Join-Path $root 'Invoke-A3Arm.ps1'
foreach ($chunk in @(250, 600, 768)) {
    $runId = "static_validate_chunk$chunk"
    & $powershell `
        -NoProfile `
        -ExecutionPolicy Bypass `
        -File $armScript `
        -Mode ValidateOnly `
        -Lane Short `
        -PrefillChunk $chunk `
        -G73Open Pending `
        -RunId $runId `
        -OutputRoot $ValidationRoot
    if ($LASTEXITCODE -ne 0) {
        throw "ValidateOnly failed for chunk $chunk"
    }
    $receiptPath = Join-Path (Join-Path $ValidationRoot $runId) 'arm_receipt.json'
    $receipt = [System.IO.File]::ReadAllText(
        $receiptPath, [System.Text.Encoding]::UTF8) | ConvertFrom-Json
    $checks["validate_only_no_server_chunk_$chunk"] =
        $receipt.status -eq 'VALIDATED_ONLY' -and -not [bool]$receipt.server_started
    if (-not $checks["validate_only_no_server_chunk_$chunk"]) {
        throw "ValidateOnly receipt gate failed for chunk $chunk"
    }
}

$campaignRoot = Join-Path $ValidationRoot 'campaigns'
& $powershell `
    -NoProfile `
    -ExecutionPolicy Bypass `
    -File (Join-Path $root 'Invoke-A3ABBA.ps1') `
    -Mode ValidateOnly `
    -G73Open Pending `
    -ArmAChunk 250 `
    -ArmBChunk 600 `
    -OutputRoot $campaignRoot
if ($LASTEXITCODE -ne 0) { throw 'ABBA ValidateOnly failed' }
$campaignSummary = Get-ChildItem -LiteralPath $campaignRoot `
    -Recurse -Filter campaign_summary.json -File |
    Sort-Object LastWriteTimeUtc -Descending |
    Select-Object -First 1
if (-not $campaignSummary) { throw 'ABBA validation summary missing' }
$summary = [System.IO.File]::ReadAllText(
    $campaignSummary.FullName, [System.Text.Encoding]::UTF8) | ConvertFrom-Json
$checks.abba_validate_only = $summary.status -eq 'VALIDATED_ONLY'
$checks.abba_receipt_count_8 = [int]$summary.receipt_count -eq 8
$checks.abba_pending_not_run_ready =
    [bool]$summary.harness_ready -and -not [bool]$summary.run_ready

# Exercise the real-summary branch with synthetic receipts only. This validates
# grouping, exact-output, separate metrics, delta direction and the 768 gate
# without invoking the server.
$syntheticRoot = Join-Path $ValidationRoot 'synthetic_campaign'
New-Item -ItemType Directory -Path $syntheticRoot -Force | Out-Null
$sequence = @(
    [ordered]@{ slot = 1; chunk = 250 },
    [ordered]@{ slot = 2; chunk = 600 },
    [ordered]@{ slot = 3; chunk = 600 },
    [ordered]@{ slot = 4; chunk = 250 }
)
foreach ($entry in $sequence) {
    foreach ($lane in @('Short', 'Prefill')) {
        $dir = Join-Path $syntheticRoot ("slot{0}_{1}" -f
            $entry.slot, $lane.ToLowerInvariant())
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
        $isB = $entry.chunk -eq 600
        $throughput = if ($isB) { 2.4 } else { 2.0 }
        $wall = if ($isB) { 1.2 } else { 1.0 }
        $ttft = if ($isB) { 80.0 } else { 100.0 }
        $requests = if ($lane -eq 'Short') {
            @(
                [ordered]@{
                    content_sha256 = ('a' * 64)
                    graph_tps = $throughput
                    decode_server_tps = $throughput
                    wall_tps_including_ttft = $wall
                    ttft_server_seconds = $ttft
                },
                [ordered]@{ content_sha256 = ('b' * 64) }
            )
        } else {
            @(
                [ordered]@{
                    content_sha256 = ('c' * 64)
                    prefill_tps_computed_only = $throughput
                    ttft_server_seconds = $ttft
                }
            )
        }
        $fake = [ordered]@{
            schema = 'ds4_a3_arm_receipt_v1'
            status = 'PASS'
            server_started = $true
            lane = $lane
            treatment = [ordered]@{
                prefill_chunk = $entry.chunk
                g73_open = '1'
            }
            geometry = [ordered]@{
                expected_raw_rows = if ($isB) { 768 } else { 512 }
            }
            manifest = [ordered]@{
                count = 47
                non_treatment_sha256 = ('d' * 64)
            }
            provenance = [ordered]@{
                executable_sha256 = ('e' * 64)
                model_sha256_expected_receipt = ('f' * 64)
                source_sha256 = [ordered]@{
                    'ds4.c' = ('1' * 64)
                    'ds4_cuda.cu' = ('2' * 64)
                    'ds4_gpu.h' = ('3' * 64)
                }
            }
            requests = $requests
            gates = [ordered]@{ overall = $true }
        }
        Write-A3Json -Value $fake -Path (Join-Path $dir 'arm_receipt.json')
    }
}
& $powershell `
    -NoProfile `
    -ExecutionPolicy Bypass `
    -File (Join-Path $root 'Summarize-A3Campaign.ps1') `
    -CampaignDirectory $syntheticRoot `
    -ArmAChunk 250 `
    -ArmBChunk 600
if ($LASTEXITCODE -ne 0) { throw 'synthetic campaign summary failed' }
$syntheticSummary = [System.IO.File]::ReadAllText(
    (Join-Path $syntheticRoot 'campaign_summary.json'),
    [System.Text.Encoding]::UTF8) | ConvertFrom-Json
$checks.synthetic_summary_pass = $syntheticSummary.status -eq 'PASS'
$checks.synthetic_add_768_true = [bool]$syntheticSummary.add_768
$checks.synthetic_prefill_delta_separate =
    [double]$syntheticSummary.metrics.prefill_computed_only_tps.delta_percent -eq 20.0
$checks.synthetic_short_graph_delta_separate =
    [double]$syntheticSummary.metrics.short_turn1_graph_tps.delta_percent -eq 20.0
if ($checks.Values -contains $false) {
    throw 'one or more A3 harness checks failed'
}

$report = [ordered]@{
    schema = 'ds4_a3_static_validation_v1'
    generated_utc = (Get-Date).ToUniversalTime().ToString('o')
    server_started = $false
    checks = $checks
    status = 'PASS'
}
$reportPath = Join-Path $ValidationRoot 'static_validation.json'
Write-A3Json -Value $report -Path $reportPath
Write-Output "A3_STATIC_VALIDATION=$reportPath"
