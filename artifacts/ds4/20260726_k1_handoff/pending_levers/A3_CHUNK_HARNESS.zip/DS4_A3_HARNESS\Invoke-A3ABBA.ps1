param(
    [ValidateSet('ValidateOnly', 'Run')]
    [string]$Mode = 'ValidateOnly',
    [ValidateSet('Pending', '0', '1')]
    [string]$G73Open = 'Pending',
    [ValidateSet(250, 600, 768)]
    [int]$ArmAChunk = 250,
    [ValidateSet(250, 600, 768)]
    [int]$ArmBChunk = 600,
    [string]$SourceRoot =
        'C:\Users\imanu\Documents\Codex\2026-07-25\legg\work\wt-hot-reserve',
    [string]$ExePath = '',
    [string]$ModelPath = 'C:\ds4-models\ds4-2bit.gguf',
    [string]$OutputRoot = ''
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
. (Join-Path $root 'A3.Common.ps1')

if ($ArmAChunk -eq $ArmBChunk) { throw 'A and B chunks must differ' }
if ($Mode -eq 'Run' -and $G73Open -eq 'Pending') {
    throw 'Run is blocked until A2 supplies -G73Open 0 or 1'
}
if ([string]::IsNullOrWhiteSpace($OutputRoot)) {
    $OutputRoot = Join-Path $root 'campaigns'
}
$campaignId = '{0}_a3_abba_{1}v{2}_g73-{3}_{4}' -f
    (Get-Date -Format 'yyyyMMdd_HHmmss'),
    $ArmAChunk,
    $ArmBChunk,
    $G73Open.ToLowerInvariant(),
    ([guid]::NewGuid().ToString('N').Substring(0, 8))
$campaignDirectory = Join-Path $OutputRoot $campaignId
New-Item -ItemType Directory -Path $campaignDirectory -Force | Out-Null

$sequence = @(
    [ordered]@{ slot = 1; arm = 'A'; chunk = $ArmAChunk },
    [ordered]@{ slot = 2; arm = 'B'; chunk = $ArmBChunk },
    [ordered]@{ slot = 3; arm = 'B'; chunk = $ArmBChunk },
    [ordered]@{ slot = 4; arm = 'A'; chunk = $ArmAChunk }
)
$campaignManifest = [ordered]@{
    schema = 'ds4_a3_campaign_manifest_v1'
    created_utc = (Get-Date).ToUniversalTime().ToString('o')
    mode = $Mode
    g73_open = $G73Open
    arm_a_chunk = $ArmAChunk
    arm_b_chunk = $ArmBChunk
    order = 'ABBA'
    lanes = @('Short', 'Prefill')
    independent_processes = 8
    sequence = $sequence
    note = 'Each lane gets a fresh server process; no cross-lane warm-state composition.'
}
Write-A3Json -Value $campaignManifest `
    -Path (Join-Path $campaignDirectory 'campaign_manifest.json')

$armScript = Join-Path $root 'Invoke-A3Arm.ps1'
$powershell = Join-Path $PSHOME 'powershell.exe'
$receipts = @()
foreach ($entry in $sequence) {
    foreach ($lane in @('Short', 'Prefill')) {
        $runId = 'slot{0}_{1}_{2}_chunk{3}' -f
            $entry.slot,
            $entry.arm.ToLowerInvariant(),
            $lane.ToLowerInvariant(),
            $entry.chunk
        $arguments = @(
            '-NoProfile',
            '-ExecutionPolicy', 'Bypass',
            '-File', $armScript,
            '-Mode', $Mode,
            '-Lane', $lane,
            '-PrefillChunk', [string]$entry.chunk,
            '-G73Open', $G73Open,
            '-RunId', $runId,
            '-SourceRoot', $SourceRoot,
            '-ModelPath', $ModelPath,
            '-OutputRoot', $campaignDirectory
        )
        if (-not [string]::IsNullOrWhiteSpace($ExePath)) {
            $arguments += @('-ExePath', $ExePath)
        }
        & $powershell @arguments
        if ($LASTEXITCODE -ne 0) {
            throw "arm failed: slot=$($entry.slot) lane=$lane chunk=$($entry.chunk)"
        }
        $receiptPath = Join-Path (Join-Path $campaignDirectory $runId) 'arm_receipt.json'
        if (-not (Test-Path -LiteralPath $receiptPath)) {
            throw "arm receipt missing: $receiptPath"
        }
        $receipts += $receiptPath
    }
}

$summaryScript = Join-Path $root 'Summarize-A3Campaign.ps1'
& $powershell `
    -NoProfile `
    -ExecutionPolicy Bypass `
    -File $summaryScript `
    -CampaignDirectory $campaignDirectory `
    -ArmAChunk $ArmAChunk `
    -ArmBChunk $ArmBChunk
if ($LASTEXITCODE -ne 0) { throw 'campaign summarizer failed' }
Write-Output "A3_CAMPAIGN=$campaignDirectory"
