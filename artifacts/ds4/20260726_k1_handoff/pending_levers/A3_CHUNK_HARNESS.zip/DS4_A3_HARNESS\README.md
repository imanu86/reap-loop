# DS4 A3 standalone harness

Questo bundle prepara A3 senza modificare `wt-hot-reserve`, il runner
`runtime_p0p1` o il ledger. Il default è `ValidateOnly`; in tale modalità
nessun processo DS4 può essere avviato.

## Stato e trattamento

- `PrefillChunk`: solo 250, 600 o 768.
- `G73Open`: `Pending`, `0` o `1`.
- `Run` rifiuta `Pending`; il valore deve arrivare dal risultato A2 sullo
  stesso binario.
- Il manifest base resta 47/47. Chunk e G73 sostituiscono le rispettive righe;
  non diventano variabili 48/49.
- `DS4_METAL_GRAPH_RAW_CAP`, graph-device e le quattro micro-patch P2/P3 sono
  controlli espliciti `<UNSET>`.

## Validazione senza DS4

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Test-A3Harness.ps1

powershell -NoProfile -ExecutionPolicy Bypass -File .\Invoke-A3ABBA.ps1 `
  -Mode ValidateOnly -G73Open Pending -ArmAChunk 250 -ArmBChunk 600
```

`Test-A3Harness.ps1` esegue parser PowerShell, manifest/geometry tests,
ValidateOnly 250/600/768 e una campagna ABBA ValidateOnly da otto receipt.
La readiness dell'harness è distinta dalla readiness degli artefatti esterni:
un source/build receipt in drift viene registrato e blocca `Run`, ma non rende
fallita la validazione statica del bundle.

## Esecuzione futura, non effettuata durante la preparazione

Dopo A2 sostituire `N` con 0 o 1:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Invoke-A3ABBA.ps1 `
  -Mode Run -G73Open N -ArmAChunk 250 -ArmBChunk 600
```

La campagna usa otto processi freddi: ABBA × lane `Short` e `Prefill`.
`Short` esegue il lifecycle deterministico 128+32 con suffisso cached <32.
`Prefill` usa un prompt deterministico e fallisce se `computed_tokens <= 600`.
Il summary mantiene separati prefill t/s, TTFT, decode server t/s, graph t/s e
wall t/s comprensivo di TTFT.

768 va eseguito come nuova ABBA 600/768 soltanto se il summary 250/600 produce
`add_768=true`.

## Receipt

Ogni arm salva:

- manifest effettivo e hash non-treatment;
- hash di exe, sorgenti e harness; modello come receipt SHA noto + byte size;
- geometria teorica e `context buffers`/raw rows osservati;
- prompt/cached/computed/completion;
- prefill, TTFT, decode wall/server/graph separati;
- righe raw di staged KV, VRAM ledger, allocation tracer, cache sizing e route;
- monitor RAM/VRAM/util/power;
- output hash, snapshot preservation, fallback e shutdown.

Il summarizer rifiuta una campagna se cambia binario, sorgente, modello,
manifest non-treatment o G73.

## Merge instructions

Nessun merge è necessario per usare il bundle standalone. Per integrare in un
runner condiviso, dopo approvazione:

1. aggiungere `PrefillChunk` con `ValidateSet(250,600,768)` e `G73Open` come
   parametro esplicito;
2. renderizzare una copia del manifest sostituendo le righe 41 e 44, mantenendo
   il conteggio 47;
3. portare le funzioni geometry/request/runtime receipt da `A3.Common.ps1`;
4. mantenere `ValidateOnly` prima di ogni `Start-Process`;
5. integrare le lane come processi separati, non due richieste nello stesso
   server;
6. integrare `Summarize-A3Campaign.ps1` senza cambiare il gate `<10%=varianza`;
7. rieseguire `Test-A3Harness.ps1`, poi review del diff; non applicare percentuali
   o output provenienti da binari differenti.
